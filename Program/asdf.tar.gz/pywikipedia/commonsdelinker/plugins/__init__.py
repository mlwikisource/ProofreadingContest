__version__ = '$Id: __init__.py 7128 2009-08-07 17:15:59Z siebrand $'
