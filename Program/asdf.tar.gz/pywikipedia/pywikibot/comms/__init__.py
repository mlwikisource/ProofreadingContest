# -*- coding: utf-8  -*-
#
# (C) Pywikipedia bot team, 2012
#
# Distributed under the terms of the MIT license.
#
__version__ = '$Id: __init__.py 9901 2012-02-16 22:44:36Z drtrigon $'
