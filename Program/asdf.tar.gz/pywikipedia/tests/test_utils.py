"""
Support module for PyWikipediaBot regression tests.
"""
__version__ = '$Id: test_utils.py 9197 2011-04-25 08:57:30Z xqt $'

import sys

# Add current directory and parent directory to module search path.
sys.path.insert(0, '..')
sys.path.insert(0, '.')

del sys
