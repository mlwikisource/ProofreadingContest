for a in *test.py ;do ./$a $1 ; done
